This is my First game lol.
Bugs Please message Xplore#8013 on Discord. Type R too return too the Menu screen and you have too Solve the words
Levels(So Far)
Police
Nasa
(Secret Level in Dev)
You can still claim the secret level if you can find it
--------------------------------------------------------
Soon.
7 new maps